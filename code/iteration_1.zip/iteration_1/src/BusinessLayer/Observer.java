package BusinessLayer;


public interface Observer {
	
	public void update();

}
