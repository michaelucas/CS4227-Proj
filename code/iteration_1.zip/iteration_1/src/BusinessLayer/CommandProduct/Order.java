package BusinessLayer.CommandProduct;

public interface Order {
	   void execute();
}
