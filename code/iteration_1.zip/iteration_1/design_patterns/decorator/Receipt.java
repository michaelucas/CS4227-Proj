abstract public class Receipt {
	
	abstract public String printReceipt();
}

