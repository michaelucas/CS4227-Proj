package Observer;

public interface Observer {
	
	public void update();

}
