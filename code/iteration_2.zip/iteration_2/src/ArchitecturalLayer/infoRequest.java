package ArchitecturalLayer;

public interface infoRequest {
	public String getType();
	public int getComponentID();
}
