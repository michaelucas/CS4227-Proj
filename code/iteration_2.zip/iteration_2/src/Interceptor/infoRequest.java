package Interceptor;

//ContextObject Interface
public interface infoRequest {
	public String getType();
	public int getComponentID();

}
