package BusinessLayer.CommandProduct;

@FunctionalInterface
public interface Order {
	   void execute();
}
