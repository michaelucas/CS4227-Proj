package BusinessLayer.ObserverProduct;

@FunctionalInterface
public interface Observer {
	
	public void update();

}
